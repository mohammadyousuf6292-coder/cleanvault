package com.cleanvault.app.ui

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.PersistableBundle
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.cleanvault.app.data.PasswordItem
import com.cleanvault.app.data.VaultDb
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.security.SecureRandom

fun generatePassword(length: Int = 20): String {
    val sets = listOf("abcdefghijkmnopqrstuvwxyz", "ABCDEFGHJKLMNPQRSTUVWXYZ", "23456789", "!@#$%^&*-_=+?")
    val r = SecureRandom()
    val all = sets.joinToString("")
    val chars = MutableList(length) { all[r.nextInt(all.length)] }
    sets.forEachIndexed { i, s -> chars[i] = s[r.nextInt(s.length)] } // guarantee each class
    chars.shuffle(r)
    return chars.joinToString("")
}

/** 0 = very weak … 4 = strong */
fun strength(p: String): Int {
    if (p.isEmpty()) return 0
    var classes = 0
    if (p.any(Char::isLowerCase)) classes++
    if (p.any(Char::isUpperCase)) classes++
    if (p.any(Char::isDigit)) classes++
    if (p.any { !it.isLetterOrDigit() }) classes++
    val score = (if (p.length >= 8) 1 else 0) + (if (p.length >= 12) 1 else 0) + (if (p.length >= 16) 1 else 0) + (if (classes >= 3) 1 else 0)
    return if (p.length < 6) 0 else score.coerceAtMost(4)
}
private val strengthLabels = listOf("Very weak", "Weak", "Fair", "Good", "Strong")

private fun copySensitive(c: Context, text: String) {
    val cm = c.getSystemService(ClipboardManager::class.java)
    val clip = ClipData.newPlainText("password", text)
    if (Build.VERSION.SDK_INT >= 33) {
        clip.description.extras = PersistableBundle().apply { putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true) }
    }
    cm.setPrimaryClip(clip)
    Toast.makeText(c, "Copied. Clear your clipboard after use.", Toast.LENGTH_SHORT).show()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PasswordsScreen(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val dao = remember { VaultDb.get(ctx).passwordDao() }
    val scope = rememberCoroutineScope()
    val rows by dao.all().collectAsState(initial = null)
    val entries by produceState<List<PasswordItem>?>(null, rows) {
        val r = rows
        value = if (r == null) null else withContext(Dispatchers.Default) {
            r.mapNotNull { runCatching { PasswordItem.from(it) }.getOrNull() }
        }
    }
    var query by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<PasswordItem?>(null) }
    var deleting by remember { mutableStateOf<PasswordItem?>(null) }

    Scaffold(modifier, floatingActionButton = {
        FloatingActionButton({ editing = PasswordItem(0, "", "", "", "", "") }) { Icon(Icons.Default.Add, "Add entry") }
    }) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 20.dp)) {
            Text("Password vault", style = MaterialTheme.typography.headlineMedium)
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(vertical = 8.dp),
                label = { Text("Search") }, singleLine = true)
            val list = entries
            when {
                list == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                list.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("No saved passwords yet. Tap + to add one.") }
                else -> {
                    val shown = list.filter { query.isBlank() || it.name.contains(query, true) || it.username.contains(query, true) }
                    if (shown.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("No matches.") }
                    else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 88.dp)) {
                        items(shown, key = { it.id }) { e ->
                            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                                Column(Modifier.padding(16.dp)) {
                                    Text(e.name, style = MaterialTheme.typography.titleMedium)
                                    if (e.username.isNotBlank()) Text(e.username, style = MaterialTheme.typography.bodyMedium)
                                    Row {
                                        TextButton({ copySensitive(ctx, e.password) }) { Text("Copy password") }
                                        TextButton({ editing = e }) { Text("Edit") }
                                        TextButton({ deleting = e }) { Text("Delete") }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    editing?.let { item ->
        var name by remember { mutableStateOf(item.name) }
        var user by remember { mutableStateOf(item.username) }
        var pass by remember { mutableStateOf(item.password) }
        var mail by remember { mutableStateOf(item.email) }
        var notes by remember { mutableStateOf(item.notes) }
        var show by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text(if (item.id == 0L) "New entry" else "Edit entry") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(name, { name = it }, label = { Text("Website or app") }, singleLine = true)
                    OutlinedTextField(user, { user = it }, label = { Text("Username") }, singleLine = true)
                    OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, singleLine = true,
                        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton({ show = !show }) { Text(if (show) "Hide" else "Show") }
                        TextButton({ pass = generatePassword(); show = true }) { Text("Generate") }
                        Text(strengthLabels[strength(pass)], style = MaterialTheme.typography.labelMedium)
                    }
                    LinearProgressIndicator(progress = { (strength(pass) + 1) / 5f }, Modifier.fillMaxWidth())
                    OutlinedTextField(mail, { mail = it }, label = { Text("Email") }, singleLine = true)
                    OutlinedTextField(notes, { notes = it }, label = { Text("Notes") })
                }
            },
            confirmButton = {
                TextButton(enabled = name.isNotBlank(), onClick = {
                    val toSave = item.copy(name = name.trim(), username = user, password = pass, email = mail, notes = notes)
                    editing = null
                    scope.launch(Dispatchers.IO) {
                        try { dao.upsert(toSave.toEntity()) }
                        catch (e: Exception) { withContext(Dispatchers.Main) { Toast.makeText(ctx, "Could not save entry.", Toast.LENGTH_LONG).show() } }
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton({ editing = null }) { Text("Cancel") } }
        )
    }

    deleting?.let { item ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete entry?") },
            text = { Text("\"${item.name}\" will be permanently deleted. This cannot be undone.") },
            confirmButton = { TextButton({ deleting = null; scope.launch(Dispatchers.IO) { dao.delete(item.id) } }) { Text("Delete") } },
            dismissButton = { TextButton({ deleting = null }) { Text("Cancel") } }
        )
    }
}
