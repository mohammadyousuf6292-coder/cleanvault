package com.cleanvault.app.ui

import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.cleanvault.app.security.Biometrics
import com.cleanvault.app.security.PinManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SettingsScreen(activity: FragmentActivity, modifier: Modifier = Modifier) {
    val pm = remember { PinManager(activity.applicationContext) }
    val bioAvailable = remember { Biometrics.available(activity) }
    var bio by remember { mutableStateOf(pm.biometricEnabled) }
    var changePin by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        Text("Security", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Biometric unlock")
                Text(if (bioAvailable) "Use fingerprint or face to unlock." else "No strong biometrics enrolled on this device.",
                    style = MaterialTheme.typography.bodySmall)
            }
            Switch(bio, { bio = it; pm.biometricEnabled = it }, enabled = bioAvailable)
        }
        Button({ changePin = true }, Modifier.fillMaxWidth()) { Text("Change PIN") }
        message?.let { Text(it) }
        Text("The app locks immediately when it goes to the background. Failed PIN attempts trigger increasing delays after 5 tries. There is no PIN recovery: if you forget it, encrypted data cannot be recovered.",
            style = MaterialTheme.typography.bodySmall)

        Text("System", style = MaterialTheme.typography.titleMedium)
        OutlinedButton({ openSystemScreen(activity, Settings.ACTION_SETTINGS) }, Modifier.fillMaxWidth()) { Text("Open Android settings") }
        OutlinedButton({ openSystemScreen(activity, Settings.ACTION_INTERNAL_STORAGE_SETTINGS) }, Modifier.fillMaxWidth()) { Text("Storage settings") }

        Text("Privacy", style = MaterialTheme.typography.titleMedium)
        Text("CleanVault works fully offline. It has no internet permission, no analytics and no cloud upload. Passwords are encrypted with an Android Keystore key that never leaves the device. Backups are disabled.",
            style = MaterialTheme.typography.bodyMedium)
        Text("About", style = MaterialTheme.typography.titleMedium)
        Text("CleanVault 0.1.0", style = MaterialTheme.typography.bodyMedium)
    }

    if (changePin) {
        var old by remember { mutableStateOf("") }
        var new by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        val scope = rememberCoroutineScope()
        val kb = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
        AlertDialog(
            onDismissRequest = { changePin = false },
            title = { Text("Change PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(old, { old = it.filter(Char::isDigit).take(12) }, label = { Text("Current PIN") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(), keyboardOptions = kb)
                    OutlinedTextField(new, { new = it.filter(Char::isDigit).take(12) }, label = { Text("New PIN (6 to 12 digits)") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(), keyboardOptions = kb)
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton({
                    if (new.length < 6) { err = "New PIN must be at least 6 digits."; return@TextButton }
                    scope.launch {
                        val ok = withContext(Dispatchers.Default) { pm.verify(old).also { if (it) pm.setPin(new) } }
                        if (ok) { changePin = false; message = "PIN changed." }
                        else err = if (pm.lockRemainingMs() > 0) "Too many attempts. Try later." else "Current PIN is incorrect."
                    }
                }) { Text("Change") }
            },
            dismissButton = { TextButton({ changePin = false }) { Text("Cancel") } }
        )
    }
}
