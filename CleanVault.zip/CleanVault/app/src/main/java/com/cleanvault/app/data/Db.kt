package com.cleanvault.app.data

import android.content.Context
import androidx.room.*
import com.cleanvault.app.security.KeystoreCrypto
import kotlinx.coroutines.flow.Flow
import org.json.JSONObject

@Entity(tableName = "passwords")
data class PasswordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val payload: String,          // Keystore-encrypted JSON; nothing readable is stored in plain text
    val updatedAt: Long
)

@Dao
interface PasswordDao {
    @Query("SELECT * FROM passwords ORDER BY updatedAt DESC")
    fun all(): Flow<List<PasswordEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(e: PasswordEntity)
    @Query("DELETE FROM passwords WHERE id = :id")
    suspend fun delete(id: Long)
}

@Database(entities = [PasswordEntity::class], version = 1, exportSchema = false)
abstract class VaultDb : RoomDatabase() {
    abstract fun passwordDao(): PasswordDao
    companion object {
        @Volatile private var inst: VaultDb? = null
        fun get(c: Context): VaultDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, VaultDb::class.java, "vault.db").build().also { inst = it }
        }
    }
}

data class PasswordItem(
    val id: Long = 0, val name: String, val username: String, val password: String,
    val email: String, val notes: String
) {
    fun toEntity() = PasswordEntity(
        id, KeystoreCrypto.encrypt(
            JSONObject().put("n", name).put("u", username).put("p", password)
                .put("e", email).put("x", notes).toString()
        ), System.currentTimeMillis()
    )
    companion object {
        fun from(e: PasswordEntity): PasswordItem {
            val j = JSONObject(KeystoreCrypto.decrypt(e.payload))
            return PasswordItem(e.id, j.getString("n"), j.getString("u"), j.getString("p"), j.getString("e"), j.getString("x"))
        }
    }
}
