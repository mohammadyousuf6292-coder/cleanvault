package com.cleanvault.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val Light = lightColorScheme(
    primary = Color.Black, onPrimary = Color.White, background = Color.White, onBackground = Color.Black,
    surface = Color.White, onSurface = Color.Black, surfaceVariant = Color(0xFFF2F2F2), onSurfaceVariant = Color(0xFF555555),
    secondaryContainer = Color(0xFFE6E6E6), onSecondaryContainer = Color.Black, error = Color(0xFFB00020)
)
private val Dark = darkColorScheme(
    primary = Color.White, onPrimary = Color.Black, background = Color.Black, onBackground = Color.White,
    surface = Color.Black, onSurface = Color.White, surfaceVariant = Color(0xFF1A1A1A), onSurfaceVariant = Color(0xFFAAAAAA),
    secondaryContainer = Color(0xFF2A2A2A), onSecondaryContainer = Color.White, error = Color(0xFFFF6B6B)
)

@Composable
fun CleanVaultTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (isSystemInDarkTheme()) Dark else Light,
        shapes = Shapes(small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(20.dp), large = RoundedCornerShape(28.dp)),
        content = { Surface(color = MaterialTheme.colorScheme.background, content = content) }
    )
}
