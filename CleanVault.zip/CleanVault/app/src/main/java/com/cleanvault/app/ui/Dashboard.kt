package com.cleanvault.app.ui

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.format.Formatter
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.cleanvault.app.device.DeviceStats
import com.cleanvault.app.device.DeviceStatsReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

fun openSystemScreen(c: Context, action: String) {
    try { c.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (e: ActivityNotFoundException) { Toast.makeText(c, "Not available on this device.", Toast.LENGTH_SHORT).show() }
}

@Composable
fun DashboardScreen(modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    var stats by remember { mutableStateOf<DeviceStats?>(null) }
    var failed by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        failed = false
        stats = runCatching { withContext(Dispatchers.IO) { DeviceStatsReader.read(ctx) } }.onFailure { failed = true }.getOrNull()
    }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Device health", style = MaterialTheme.typography.headlineMedium)
        val s = stats
        when {
            failed -> Text("Could not read device information.", color = MaterialTheme.colorScheme.error)
            s == null -> Box(Modifier.fillMaxWidth().height(200.dp), Alignment.Center) { CircularProgressIndicator() }
            else -> {
                HealthRing(s.health)
                Text(
                    "Score = average of free RAM and free storage. It is an indicator only; CleanVault cannot free RAM for you.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                StatCard("Memory (RAM)", "${Formatter.formatFileSize(ctx, s.ramTotal - s.ramFree)} used of ${Formatter.formatFileSize(ctx, s.ramTotal)}")
                StatCard("Storage", "${Formatter.formatFileSize(ctx, s.storageTotal - s.storageFree)} used, ${Formatter.formatFileSize(ctx, s.storageFree)} free")
                StatCard("Battery", (if (s.batteryPct >= 0) "${s.batteryPct}%" else "Unavailable") + if (s.charging) " (charging)" else "")
                StatCard("Temperature", s.tempC?.let { "%.1f °C (battery sensor)".format(it) } ?: "Not available on this device")
                OutlinedButton({ tick++ }, Modifier.fillMaxWidth()) { Text("Refresh") }
            }
        }
        Text("System shortcuts", style = MaterialTheme.typography.titleMedium)
        Button({ openSystemScreen(ctx, Settings.ACTION_INTERNAL_STORAGE_SETTINGS) }, Modifier.fillMaxWidth()) { Text("Storage settings") }
        Button({ openSystemScreen(ctx, Settings.ACTION_BATTERY_SAVER_SETTINGS) }, Modifier.fillMaxWidth()) { Text("Battery settings") }
        Button({ openSystemScreen(ctx, Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS) }, Modifier.fillMaxWidth()) { Text("App management (Force Stop lives here)") }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(16.dp)) {
                Text("Virtual RAM", style = MaterialTheme.typography.titleSmall)
                Text("RAM Expansion is controlled by your device manufacturer and Android version. CleanVault cannot create extra RAM.", style = MaterialTheme.typography.bodyMedium)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(16.dp)) {
                Text("Coming in the next build", style = MaterialTheme.typography.titleSmall)
                Text("Junk cleaner, security scanner and the encrypted file vault are not implemented yet, so they are not shown as working.", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun HealthRing(score: Int) {
    val track = MaterialTheme.colorScheme.secondaryContainer
    val fill = MaterialTheme.colorScheme.primary
    Box(Modifier.fillMaxWidth().height(200.dp), Alignment.Center) {
        Canvas(Modifier.size(180.dp)) {
            val w = 18.dp.toPx()
            val inset = w / 2
            val sz = Size(size.width - w, size.height - w)
            drawArc(track, 0f, 360f, false, Offset(inset, inset), sz, style = Stroke(w))
            drawArc(fill, -90f, 360f * score / 100f, false, Offset(inset, inset), sz, style = Stroke(w, cap = StrokeCap.Round))
        }
        Text("$score", style = MaterialTheme.typography.displayMedium)
    }
}

@Composable
private fun StatCard(title: String, value: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.titleMedium)
        }
    }
}
