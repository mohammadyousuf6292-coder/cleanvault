package com.cleanvault.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import com.cleanvault.app.security.SessionLock
import com.cleanvault.app.ui.*

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Blocks screenshots and hides content in the recents screen.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        enableEdgeToEdge()
        setContent { CleanVaultTheme { Root(this) } }
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations) SessionLock.lock() // lock immediately when app goes to background
    }
}

@Composable
private fun Root(activity: FragmentActivity) {
    if (!SessionLock.unlocked) { LockScreen(activity); return }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(bottomBar = {
        NavigationBar {
            NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
            NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.Lock, null) }, label = { Text("Passwords") })
            NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
        }
    }) { pad ->
        val m = Modifier.padding(pad)
        when (tab) {
            0 -> DashboardScreen(m)
            1 -> PasswordsScreen(m)
            else -> SettingsScreen(activity, m)
        }
    }
}
