package com.cleanvault.app.security

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Stores only a salted PBKDF2 hash of the PIN, with escalating lockout after failed attempts. */
class PinManager(context: Context) {
    private val p = context.getSharedPreferences("cv_auth", Context.MODE_PRIVATE)

    fun hasPin() = p.contains("hash")
    var biometricEnabled: Boolean
        get() = p.getBoolean("bio", false)
        set(v) { p.edit().putBoolean("bio", v).apply() }

    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)).encoded

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", Base64.encodeToString(hash(pin, salt), Base64.NO_WRAP))
            .putInt("fails", 0).putLong("until", 0).apply()
    }

    fun lockRemainingMs(): Long = (p.getLong("until", 0) - System.currentTimeMillis()).coerceAtLeast(0)

    /** Returns true if the PIN is correct. Wrong attempts count towards lockout. */
    fun verify(pin: String): Boolean {
        if (lockRemainingMs() > 0) return false
        val salt = Base64.decode(p.getString("salt", "") ?: "", Base64.NO_WRAP)
        val stored = Base64.decode(p.getString("hash", "") ?: "", Base64.NO_WRAP)
        val ok = MessageDigest.isEqual(stored, hash(pin, salt))
        val e = p.edit()
        if (ok) e.putInt("fails", 0).putLong("until", 0)
        else {
            val f = p.getInt("fails", 0) + 1
            e.putInt("fails", f)
            if (f >= 5) e.putLong("until", System.currentTimeMillis() + 30_000L * (1L shl minOf(f - 5, 6)))
        }
        e.apply()
        return ok
    }
}
