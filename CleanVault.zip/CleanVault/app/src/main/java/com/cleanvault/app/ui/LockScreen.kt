package com.cleanvault.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.fragment.app.FragmentActivity
import com.cleanvault.app.security.Biometrics
import com.cleanvault.app.security.PinManager
import com.cleanvault.app.security.SessionLock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun LockScreen(activity: FragmentActivity) {
    val pm = remember { PinManager(activity.applicationContext) }
    var hasPin by remember { mutableStateOf(pm.hasPin()) }
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var remaining by remember { mutableLongStateOf(pm.lockRemainingMs()) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(hasPin) {
        if (hasPin && pm.biometricEnabled && Biometrics.available(activity)) {
            Biometrics.prompt(activity) { SessionLock.unlocked = true }
        }
    }
    LaunchedEffect(remaining) {
        if (remaining > 0) { delay(1000); remaining = pm.lockRemainingMs() }
    }

    Column(
        Modifier.fillMaxSize().safeDrawingPadding().padding(32.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("CleanVault", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(8.dp))
        Text(if (hasPin) "Enter your PIN" else "Create a PIN (6 to 12 digits)", style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            pin, { pin = it.filter(Char::isDigit).take(12) }, label = { Text("PIN") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            enabled = remaining == 0L && !busy
        )
        if (!hasPin) {
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                confirm, { confirm = it.filter(Char::isDigit).take(12) }, label = { Text("Confirm PIN") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
            )
            Spacer(Modifier.height(12.dp))
            Text(
                "Warning: there is no PIN recovery. If you forget your PIN, your encrypted data cannot be recovered.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error
            )
        }
        if (remaining > 0) Text("Too many attempts. Try again in ${remaining / 1000 + 1}s.", color = MaterialTheme.colorScheme.error)
        else error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                if (hasPin) {
                    busy = true
                    scope.launch {
                        val ok = withContext(Dispatchers.Default) { pm.verify(pin) }
                        busy = false; pin = ""
                        remaining = pm.lockRemainingMs()
                        if (ok) SessionLock.unlocked = true else error = "Incorrect PIN."
                    }
                } else if (pin.length < 6) error = "PIN must be at least 6 digits."
                else if (pin != confirm) error = "PINs do not match."
                else {
                    busy = true
                    scope.launch {
                        withContext(Dispatchers.Default) { pm.setPin(pin) }
                        busy = false; hasPin = true; SessionLock.unlocked = true
                    }
                }
            },
            enabled = pin.isNotEmpty() && remaining == 0L && !busy,
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(if (hasPin) "Unlock" else "Set PIN") }
        if (hasPin && pm.biometricEnabled && Biometrics.available(activity)) {
            TextButton({ Biometrics.prompt(activity) { SessionLock.unlocked = true } }) { Text("Use biometrics") }
        }
    }
}
