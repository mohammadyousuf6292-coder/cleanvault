package com.cleanvault.app.device

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs

data class DeviceStats(
    val ramTotal: Long, val ramFree: Long, val storageTotal: Long, val storageFree: Long,
    val batteryPct: Int, val tempC: Float?, val charging: Boolean
) {
    /** Simple, transparent score: average of free RAM % and free storage %. */
    val health: Int get() {
        val r = ramFree.toFloat() / ramTotal.coerceAtLeast(1)
        val s = storageFree.toFloat() / storageTotal.coerceAtLeast(1)
        return (((r + s) / 2f) * 100).toInt().coerceIn(0, 100)
    }
}

object DeviceStatsReader {
    fun read(c: Context): DeviceStats {
        val mi = ActivityManager.MemoryInfo()
        c.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val sf = StatFs(Environment.getDataDirectory().path)
        val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val t = b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE
        val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        return DeviceStats(
            mi.totalMem, mi.availMem, sf.totalBytes, sf.availableBytes,
            if (lvl >= 0 && scale > 0) lvl * 100 / scale else -1,
            if (t != Int.MIN_VALUE) t / 10f else null,
            st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        )
    }
}
