package com.cleanvault.app.security

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

object SessionLock {
    var unlocked by mutableStateOf(false)
    fun lock() { unlocked = false }
}

object Biometrics {
    private const val AUTH = BiometricManager.Authenticators.BIOMETRIC_STRONG
    fun available(c: Context) =
        BiometricManager.from(c).canAuthenticate(AUTH) == BiometricManager.BIOMETRIC_SUCCESS

    fun prompt(a: FragmentActivity, onOk: () -> Unit) {
        val cb = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) = onOk()
        }
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock CleanVault")
            .setNegativeButtonText("Use PIN")
            .setAllowedAuthenticators(AUTH)
            .build()
        BiometricPrompt(a, ContextCompat.getMainExecutor(a), cb).authenticate(info)
    }
}
